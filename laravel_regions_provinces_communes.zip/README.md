# Chile Regions/Provinces/Communes — Laravel Migrations + Seeders

**⚠️ Importante:** Se han **traducido los nombres de tablas y columnas a inglés**, pero los **datos permanecen en español**, exactamente como en los `.sql` originales.

## Tablas (en inglés)
- `regions` (`id`, `name`, `ordinal`, `geographic_order`)
- `provinces` (`id`, `name`, `region_id`)
- `communes` (`id`, `name`, `province_id`)

## Claves foráneas
- `provinces.region_id` → `regions.id`
- `communes.province_id` → `provinces.id`

## Uso
1. Copia la carpeta `database/` dentro de tu proyecto Laravel.
2. Ejecuta migraciones:
   ```bash
   php artisan migrate
   ```
3. Carga los seeders:
   ```bash
   php artisan db:seed
   ```

> Nota: Las columnas `id` **no son auto-incrementales** (coinciden con los IDs oficiales). Los seeders usan `truncate()` para evitar duplicados; asegúrate de no tener datos críticos antes de ejecutar.

## Compatibilidad
- Laravel 12 (PHP 8.2+)
- MySQL/MariaDB

## Fuente
- Basado en los SQL proporcionados: `regiones.sql`, `provincias.sql`, `comunas.sql`

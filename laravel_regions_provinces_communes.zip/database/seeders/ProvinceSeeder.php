<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProvinceSeeder extends Seeder
{
    public function run(): void
    {{
        DB::table('provinces')->truncate();
        DB::table('provinces')->insert(
            [
                ['id' => 11, 'name' => 'Iquique', 'region_id' => 1],
                ['id' => 14, 'name' => 'Tamarugal', 'region_id' => 1],
                ['id' => 21, 'name' => 'Antofagasta', 'region_id' => 2],
                ['id' => 22, 'name' => 'El Loa', 'region_id' => 2],
                ['id' => 23, 'name' => 'Tocopilla', 'region_id' => 2],
                ['id' => 31, 'name' => 'Copiapó', 'region_id' => 3],
                ['id' => 32, 'name' => 'Chañaral', 'region_id' => 3],
                ['id' => 33, 'name' => 'Huasco', 'region_id' => 3],
                ['id' => 41, 'name' => 'Elqui', 'region_id' => 4],
                ['id' => 42, 'name' => 'Choapa', 'region_id' => 4],
                ['id' => 43, 'name' => 'Limarí', 'region_id' => 4],
                ['id' => 51, 'name' => 'Valparaíso', 'region_id' => 5],
                ['id' => 52, 'name' => 'Isla de Pascua', 'region_id' => 5],
                ['id' => 53, 'name' => 'Los Andes', 'region_id' => 5],
                ['id' => 54, 'name' => 'Petorca', 'region_id' => 5],
                ['id' => 55, 'name' => 'Quillota', 'region_id' => 5],
                ['id' => 56, 'name' => 'San Antonio', 'region_id' => 5],
                ['id' => 57, 'name' => 'San Felipe de Aconcagua', 'region_id' => 5],
                ['id' => 58, 'name' => 'Marga Marga', 'region_id' => 5],
                ['id' => 61, 'name' => 'Cachapoal', 'region_id' => 6],
                ['id' => 62, 'name' => 'Cardenal Caro', 'region_id' => 6],
                ['id' => 63, 'name' => 'Colchagua', 'region_id' => 6],
                ['id' => 71, 'name' => 'Talca', 'region_id' => 7],
                ['id' => 72, 'name' => 'Cauquenes', 'region_id' => 7],
                ['id' => 73, 'name' => 'Curicó', 'region_id' => 7],
                ['id' => 74, 'name' => 'Linares', 'region_id' => 7],
                ['id' => 81, 'name' => 'Concepción', 'region_id' => 8],
                ['id' => 82, 'name' => 'Arauco', 'region_id' => 8],
                ['id' => 83, 'name' => 'Biobío', 'region_id' => 8],
                ['id' => 91, 'name' => 'Cautín', 'region_id' => 9],
                ['id' => 92, 'name' => 'Malleco', 'region_id' => 9],
                ['id' => 101, 'name' => 'Llanquihue', 'region_id' => 10],
                ['id' => 102, 'name' => 'Chiloé', 'region_id' => 10],
                ['id' => 103, 'name' => 'Osorno', 'region_id' => 10],
                ['id' => 104, 'name' => 'Palena', 'region_id' => 10],
                ['id' => 111, 'name' => 'Coihaique', 'region_id' => 11],
                ['id' => 112, 'name' => 'Aysén', 'region_id' => 11],
                ['id' => 113, 'name' => 'Capitán Prat', 'region_id' => 11],
                ['id' => 114, 'name' => 'General Carrera', 'region_id' => 11],
                ['id' => 121, 'name' => 'Magallanes', 'region_id' => 12],
                ['id' => 122, 'name' => 'Antártica Chilena', 'region_id' => 12],
                ['id' => 123, 'name' => 'Tierra del Fuego', 'region_id' => 12],
                ['id' => 124, 'name' => 'Última Esperanza', 'region_id' => 12],
                ['id' => 131, 'name' => 'Santiago', 'region_id' => 13],
                ['id' => 132, 'name' => 'Cordillera', 'region_id' => 13],
                ['id' => 133, 'name' => 'Chacabuco', 'region_id' => 13],
                ['id' => 134, 'name' => 'Maipo', 'region_id' => 13],
                ['id' => 135, 'name' => 'Melipilla', 'region_id' => 13],
                ['id' => 136, 'name' => 'Talagante', 'region_id' => 13],
                ['id' => 141, 'name' => 'Valdivia', 'region_id' => 14],
                ['id' => 142, 'name' => 'Ranco', 'region_id' => 14],
                ['id' => 151, 'name' => 'Arica', 'region_id' => 15],
                ['id' => 152, 'name' => 'Parinacota', 'region_id' => 15],
                ['id' => 161, 'name' => 'Diguillín', 'region_id' => 16],
                ['id' => 162, 'name' => 'Itata', 'region_id' => 16],
                ['id' => 163, 'name' => 'Punilla', 'region_id' => 16],
            ]
        );
    }}
}
